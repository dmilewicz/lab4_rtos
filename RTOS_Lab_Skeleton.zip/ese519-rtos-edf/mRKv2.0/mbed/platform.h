/* mbed Microcontroller Library - platform
 * Copyright (c) 2009 ARM Limited. All rights reserved.
 * sford
 */ 
 
#ifndef MBED_PLATFORM_H
#define MBED_PLATFORM_H

#define MBED_RPC
#define MBED_OPERATORS

#endif
